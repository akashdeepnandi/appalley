<?php $__env->startSection('content'); ?>
<main id="main">
    <section class="breadcrumbs">
        <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Our Team</h2>
            <ol>
            <li><a href="/">Home</a></li>
            <li><a href="/services">Services</a></li>
            <li>Our Team</li>
            </ol>
        </div>
        </div>
    </section>
    <section class="about">
        <div class="container">
            <div class="section-title">
                <h2>Services</h2>
            </div>
        </div>
    </section>
</main>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mr_void/Documents/lamp/indra/resources/views/services/mobile.blade.php ENDPATH**/ ?>