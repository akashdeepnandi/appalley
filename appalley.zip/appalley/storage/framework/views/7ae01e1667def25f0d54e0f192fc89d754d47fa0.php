<?php $__env->startSection('content'); ?>
<main id="main">

    <!-- ======= Our Services Section ======= -->
    <section class="breadcrumbs">
        <div class="container">

            <div class="d-flex justify-content-between align-items-center">
            <h2>Our Services</h2>
            <ol>
                <li><a href="/">Home</a></li>
                <li>Our Services</li>
            </ol>
            </div>

        </div>
    </section><!-- End Our Services Section -->

    <!-- ======= Services Section ======= -->
    <section class="services">
        <div class="container">

            <div class="row">
            <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up">
                <div class="icon-box icon-box-pink">
                <div class="icon"><i class="bx bxl-dribbble"></i></div>
                <h4 class="title"><a href="">Goal</a></h4>
                <p class="description">To provide the best mobile advertising service at affordable prices</p>
                </div>
            </div>
            


            <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
                <div class="icon-box icon-box-cyan">
                <div class="icon"><i class="bx bx-file"></i></div>
                <h4 class="title"><a href="">Policy</a></h4>
                <p class="description"> We respect your privacy regarding any information we may collect from you across our website,</p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
                <div class="icon-box icon-box-green">
                <div class="icon"><i class="bx bx-tachometer"></i></div>
                <h4 class="title"><a href="">Speed</a></h4>
                <p class="description">Our work force believes in rapid rapid development and high scalability</p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
                <div class="icon-box icon-box-blue">
                <div class="icon"><i class="bx bx-world"></i></div>
                <h4 class="title"><a href="">Culture</a></h4>
                <p class="description"> Culture is the persona of the organization. We prioritize consumer satisfaction above all </p>
                </div>
            </div>

            </div>

        </div>
    </section><!-- End Services Section -->

    <!-- ======= Why Us Section ======= -->
    <section class="why-us section-bg" data-aos="fade-up" date-aos-delay="200">
        <div class="container">

            <div class="row">
            <div class="col-lg-6 video-box">
                <img src="<?php echo e(asset('img/why-us.jpg')); ?>" class="img-fluid" alt="">
                
            </div>

            <div class="col-lg-6 d-flex flex-column justify-content-center p-5">
                <div class="icon-box">
                <div class="icon"><i class="bx bx-fingerprint"></i></div>
                <h4 class="title"><a href="">Specializes in providing two-fold solutions for your digital needs</a></h4>
                <p class="description">
                    
                        Growing ROI on Ad Spends (GRAS) as well as
                        Quality Audience with Worldwide Reach (QAWR)
                    
                </p>
                </div>

                <div class="icon-box">
                <div class="icon"><i class="bx bx-gift"></i></div>
                <h4 class="title"><a href="">How do we do it?</a></h4>
                <p class="description">We are a data driven technology destination for all of your digital needs. Optimize returns through pertinent targeting and insights driven optimisations.</p>
                </div>

            </div>
            </div>

        </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Service Details Section ======= -->
    <section class="service-details">
        <div class="section-title">
            <h2>SERVICES</h2>
        <div class="container">

        <div class="row">
            <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                <div class="card">
                <div class="card-img">
                    <img src="<?php echo e(asset('img/service-details-1.jpg')); ?>" alt="...">
                </div>
                <div class="card-body">
                    <h5 class="card-title"><a href="/services/display">DISPLAY | MAINSTREAM</a></h5>
                    <p class="card-text">Our campaigns inspire a trigger of response by keeping our displays informative and interactive.
                        With our equilibrium of creative experts and domain strategy specialists, 
                        ..
                        
                    </p>
                    <div class="read-more"><a href="/services/display"><i class="icofont-arrow-right"></i> Read More</a></div>
                </div>
                </div>
            </div>
            <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                <div class="card">
                <div class="card-img">
                    <img src="<?php echo e(asset('img/service-details-2.jpg')); ?>" alt="...">
                </div>
                <div class="card-body">
                    <h5 class="card-title"><a href="/services/social">SOCIAL</a></h5>
                    <p class="card-text">
                        Our focus is not limited to network and exchanges, we walk a mile further into data consolidation and optimization with social media platforms. With the growing use of social, the audience size is humongous...
                

                    </p>
                    <div class="read-more"><a href="/services/social"><i class="icofont-arrow-right"></i> Read More</a></div>
                </div>
                </div>

            </div>
            <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                <div class="card">
                <div class="card-img">
                    <img src="<?php echo e(asset('img/service-details-3.jpg')); ?>" alt="...">
                </div>
                <div class="card-body">
                    <h5 class="card-title"><a href="/services/mobile">
                        MOBILE SUBSCRIPTIONS</a></h5>
                    <p class="card-text">With an intent to increase the average revenue per telecom user beyond the calls and messages, Mobile Subscriptions or Value Added Services were introduced...
                        

                    </p>
                    <div class="read-more"><a href="/services/mobile"><i class="icofont-arrow-right"></i> Read More</a></div>
                </div>
                </div>
            </div>
            <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                <div class="card">
                <div class="card-img">
                    <img src="<?php echo e(asset('img/service-details-4.jpg')); ?>" alt="...">
                </div>
                <div class="card-body">
                    <h5 class="card-title"><a href="/services/messaging">EMAIL / SMS / VOICE / SHORT CODES / CMS</a></h5>
                    <p class="card-text">
                        With our team of specialists & technology, we have integrated SMS, emails, Voices, short codes with various ERP systems. Not only can we automate alerts on transactions,... 
                        
                    </p>
                    <div class="read-more"><a href="/services/messaging"><i class="icofont-arrow-right"></i> Read More</a></div>
                </div>
                </div>
            </div>
            </div>

        </div>
    </section><!-- End Service Details Section -->

    

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mr_void/Documents/lamp/indra/resources/views/pages/services.blade.php ENDPATH**/ ?>