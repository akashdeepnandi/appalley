<?php $__env->startSection('content'); ?>
<main id="main">
    <section class="breadcrumbs">
        <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Our Team</h2>
            <ol>
            <li><a href="/">Home</a></li>
            <li><a href="/services">Our Services</a></li>
            <li><?php echo e($service_title); ?></li>
            </ol>
        </div>
        </div>
    </section>
    <section class="about" data-aos="fade-up" date-aos-delay="200">
        <div class="container">
            <div class="section-title">
                <h2><?php echo e($service_title); ?></h2>
            </div>
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <article class="entry">
                        <div class="entry-img">
                            <img
                                src="<?php echo e(asset('img/services/' . $img. '.jpg')); ?>"
                                alt=""
                                class="img-fluid"
                            />
                        </div>
        
                        <div class="entry-content text-justify">
                            <p>
                                <?php echo $content; ?>

                            </p>
                            
                        </div>
                    </article>
                </div>
            </div>
            
        </div>
    </section>
</main>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mr_void/Documents/lamp/indra/resources/views/pages/service.blade.php ENDPATH**/ ?>